from numpy import array


def sum_a_b(a, b):
    return a + b


def numpy_array(arr_list):
    return array(arr_list)
